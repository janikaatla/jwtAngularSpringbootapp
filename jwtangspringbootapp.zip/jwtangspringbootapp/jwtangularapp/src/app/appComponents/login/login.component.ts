import { Component, OnInit } from '@angular/core';
import {AppService} from "../../services/app.service";
import {Router} from "@angular/router";
import {FormControl, FormGroup} from "@angular/forms";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  username = new FormControl();
  password = new FormControl();
  constructor(private appService: AppService, private router: Router) {
    this.loginForm = new FormGroup({
      username: this.username,
      password: this.password
    });
  }

  ngOnInit(): void {
  }

  authentication(): any {
    this.appService.authenticate(this.username.value, this.password.value).subscribe(userData => {
      sessionStorage.setItem('username', this.username.value);
      console.log(userData);
      const tokenStr = userData.userToken.token;
      console.log(tokenStr);
      sessionStorage.setItem('displayName', userData.userToken.username);
      // sessionStorage.setItem('token', tokenStr);
      localStorage.setItem('token', tokenStr);
      // return userData;
      this.router.navigate(['sidebar']);
    });
  }

}
