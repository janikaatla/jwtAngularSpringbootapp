import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  currentUser: string | null | undefined;
  btnOrgActive = true;
  btnDepActive = false;
  btnDesActive = false;
  btnComActive = false;
  btnEmpActive = false;
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.currentUser = sessionStorage.getItem('displayName');
  }

  logout() {
    sessionStorage.removeItem('displayName');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('token');
    sessionStorage.setItem('logout', 'appOut');
    this.router.navigate(['/']);
    return false;
  }

  btnActiveClick(val: string) {
    this.btnOrgActive = false;
    this.btnComActive = false;
    this.btnDepActive = false;
    this.btnDesActive = false;
    this.btnEmpActive = false;
    if (val == 'Org'){
      this.btnOrgActive = true;
    } else if (val == 'CTQ'){
      this.btnComActive = true;
    } else if (val == 'Scout'){
      this.btnDepActive = true;
    } else if (val == 'Search'){
      this.btnDesActive = true;
    } else if (val == 'Upload'){
      this.btnEmpActive = true;
    }
  }

  orgSearch() {

  }

  orgAdd() {

  }

  compSearch() {

  }

  compAdd() {

  }

  depSearch() {

  }

  depAdd() {

  }

  desSearch() {

  }

  desAdd() {

  }

  empSearch() {

  }

  empAdd() {

  }
}
