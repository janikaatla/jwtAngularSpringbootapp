import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpResponse,
  HttpErrorResponse,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable, from, timer } from 'rxjs';
import { map } from 'rxjs/operators';
import {AppService} from './app.service';


@Injectable()
export class AppInterceptor implements HttpInterceptor {
  CONTENT_TYPE = 'application/json';
  timer: any;
  subscription: any;
  constructor(private appService: AppService) {
  }
     // service function for the handel Http response errors.
  intercept( request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = localStorage.token; // you probably want to store it in localStorage or something
    console.log('token : ' + token);
    if (!token) {
      return next.handle(request);
    } else {
      const req1 = request.clone({
        headers: request.headers.set('Authorization', `Bearer ${token}`),
      });
      return next.handle(req1);
    }
  }

  /*setTimeout(() => {
    this.timer = timer(3000);
    this.subscription = this.timer.subscribe(() => {
    request = request.clone({
      setHeaders: {
        'Content-Type': this.CONTENT_TYPE,
        Authorization: `Bearer ${this.authService.getToken()}`
      }
    });
  });
  });

  return next.handle(request).pipe(map((resp: HttpResponse<any>) => {
      if (resp && resp.type === 4) {
        setTimeout(() => {
      });

        if (resp.body) {
          if (resp.body.status === 1) {
            return resp.clone({
              body: resp.body.data
            });
          } else if (resp.body.status === 0) {
            this.errorMessage(
              resp.body.error ? resp.body.error : resp.body.data
            );
            return null;
          } else {
            return resp;
          }
      } else {
          return resp;
      }
    } else {
    }
  })
);*/

  errorMessage(err: any): any {
    console.log(err);
    let message = err.message ? err.message : err;
    message = typeof message === 'string' ? message : 'Invalid data.';
    console.log('error message ' + message);
      // this.appNotificationService.error(message);
  }
}
