import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Router} from '@angular/router';
import {environment} from '../../environments/environment';
// import {LoadingOverlayRef, SpinnerOverlayService} from './spinner-overlay.service';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  // private loadingRef: LoadingOverlayRef | undefined;

  constructor(private http: HttpClient, private router: Router) { }
  // tslint:disable-next-line:variable-name
  private _url = environment.url ;

  val: string[] = [];

  // tslint:disable-next-line:typedef
  showLoader() {
    console.log('start loader called');
    // this.loadingRef = this.spinnerOverlayService.open();
  }

  // tslint:disable-next-line:typedef
  hideLoader() {
    console.log('end loader called');
    /*if (this.loadingRef) {
      this.loadingRef.close();
    }*/
  }

  // tslint:disable-next-line:typedef
  authenticate(username: string, password: string) {
    console.log(username);
    console.log(password);
    return this.http.post<any>(this._url + '/authenticate', {username, password});
    /*return this.http.post<any>(this._url, {username, password}).pipe(
      map(
        userData => {
          sessionStorage.setItem('username', username);
          const tokenStr = 'Bearer ' + userData.token;
          console.log(tokenStr);
          sessionStorage.setItem('displayName', userData.username);
          sessionStorage.setItem('token', tokenStr);
          return userData;
        }
      )
    );*/
  }

  healthCheck(): any {
    /*const token = localStorage.getItem('token');
    console.log(token);
    let headersObj = new HttpHeaders().set('Content-Type', 'application/json');
    headersObj = headersObj.append('Authorization', 'Bearer ' + token);
    headersObj = headersObj.append('Access-Control-Allow-Origin', '*');
    headersObj = headersObj.append('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
    console.log(headersObj);
    const httpOptions = {
      headers: headersObj
    };*/
    // headers: headersObj,
    return this.http.get<any>(this._url + '/health',  { responseType: 'text' as 'json'})
      .toPromise()
      .then(data => {
        console.log(data);
        return data;
      });
  }

  // tslint:disable-next-line:typedef
  login(username: string, password: string)  {
    // alert("username : "+username);
    // var userpass="'"+username+":"+password+"'";
    return this.http.post<any>(this._url, {username, password});

  }

  // tslint:disable-next-line:typedef
  isUserLoggedIn() {
    const user = sessionStorage.getItem('username');
    // console.log(!(user === null))
    return !(user === null);
  }
  // tslint:disable-next-line:typedef
  logOut() {
    sessionStorage.removeItem('username');
  }
}
