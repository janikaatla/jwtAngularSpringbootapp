/*
import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpResponse,
  HttpErrorResponse,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable, from, timer } from 'rxjs';
import { map } from 'rxjs/operators';



@Injectable()
export class AzureInterceptor implements HttpInterceptor {
  CONTENT_TYPE = 'application/json';
  timer: any;
  subscription: any;
  constructor() {
  }
  // service function for the handel Http response errors.
  intercept( request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    setTimeout(() => {
      this.timer = timer(3000);
      this.subscription = this.timer.subscribe(() => {
        request = request.clone({
          setHeaders: {
            'Content-Type': this.CONTENT_TYPE,
            Authorization: `Bearer ${this.authService.getToken()}`
          }
        });
      });
    });

    return next.handle(request).pipe(map((resp: HttpResponse<any>) => {
      if (resp && resp.type === 4) {
          setTimeout(() => {
          });

          if (resp.body) {
            if (resp.body.status === 1) {
              return resp.clone({
                body: resp.body.data
              });
            } else if (resp.body.status === 0) {
              this.errorMessage(
                resp.body.error ? resp.body.error : resp.body.data
              );
              return null;
            } else {
              return resp;
            }
          } else {
            return resp;
          }
        } else {
        }
      })
    );
  }

  errorMessage(err: any) {
    console.log(err);
    let message = err.message ? err.message : err;
    message = typeof message === 'string' ? message : 'Invalid data.';
    console.log('error message ' + message);
    // this.appNotificationService.error(message);
  }
}
*/
