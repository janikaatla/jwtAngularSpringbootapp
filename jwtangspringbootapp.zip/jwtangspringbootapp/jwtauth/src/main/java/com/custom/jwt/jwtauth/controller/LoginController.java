package com.custom.jwt.jwtauth.controller;

import java.security.Principal;
import java.util.Base64;
import java.util.Collection;
import java.util.Objects;


import com.custom.jwt.jwtauth.config.JwtRequest;
import com.custom.jwt.jwtauth.config.JwtResponse;
import com.custom.jwt.jwtauth.config.JwtTokenUtil;
import com.custom.jwt.jwtauth.model.User;
import com.custom.jwt.jwtauth.service.JwtUserDetailsService;
import com.custom.jwt.jwtauth.util.AppUsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin(origins="*", maxAge=3600)
public class LoginController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private AppUsersService appUsersService;


    @RequestMapping(value = "/health")
    public String healthCheck() {
        System.out.println("health Check");
        return "Valid";
    }

    @Autowired
    private JwtUserDetailsService jwtUserDetailsService;

    @RequestMapping(value = "/authenticate", method = RequestMethod.POST)
    public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest)
            throws Exception {

        System.out.println("authenticationRequest.getUsername() : " + authenticationRequest.getUsername());
        System.out.println("authenticationRequest.password() : " + authenticationRequest.getPassword());
        User user = appUsersService.connectUserService(authenticationRequest.getUsername(), authenticationRequest.getPassword());
        System.out.println("user1 : " + user);
		/*User user =new User();
		user.setUsername(authenticationRequest.getUsername());
		user.setPassword(authenticationRequest.getPassword());*/
        try {
            if (user != null) {
                jwtUserDetailsService.setUser(user);
                authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());

                final UserDetails userDetails = jwtUserDetailsService
                        .loadUserByUsername(authenticationRequest.getUsername());

                final String token = jwtTokenUtil.generateToken(userDetails);
                System.out.println("token : " + token);
                user.setToken(token);
                return ResponseEntity.ok(new JwtResponse(user));
            } else {

                String error = "Invalid User";
                return ResponseEntity.ok(new JwtResponse(error));
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println(e.getMessage());
            //new Exception(e.getMessage());
            String error = e.getMessage();
            return ResponseEntity.ok(new JwtResponse(error));
        }

    }

    private void authenticate(String username, String password) throws Exception {
        Objects.requireNonNull(username);
        Objects.requireNonNull(password);

        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (DisabledException e) {
            throw new Exception("USER_DISABLED", e);
        } catch (BadCredentialsException e) {
            throw new Exception("INVALID_CREDENTIALS", e);
        }
    }
}
