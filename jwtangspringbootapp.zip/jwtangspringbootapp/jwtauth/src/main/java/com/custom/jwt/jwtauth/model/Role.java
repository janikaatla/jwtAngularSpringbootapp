package com.custom.jwt.jwtauth.model;

import java.util.List;

import org.springframework.security.core.GrantedAuthority;

public class Role implements GrantedAuthority{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String rolename;
	
	public String getAuthority() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	

}
